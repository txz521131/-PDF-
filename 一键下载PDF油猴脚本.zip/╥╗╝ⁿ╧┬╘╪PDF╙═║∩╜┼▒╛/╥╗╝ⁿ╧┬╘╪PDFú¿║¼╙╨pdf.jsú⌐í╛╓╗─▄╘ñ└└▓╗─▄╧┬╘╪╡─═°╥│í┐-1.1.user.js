// ==UserScript==
// @name         一键下载PDF（含有pdf.js）【只能预览不能下载的网页】
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  PDF.js 页面：下载按钮 + 浮动下载链接可复制
// @match *://*/*
// @icon   data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAQAElEQVR4AeydB3wVVb7H/zcSOqQQCL0phBJIoaUABgQXxLW8j0/dxXVdy/pE1xVcXeu6ruv6lNXnsojK2l11dbGA0kRKKEkoJpSEjkBCMUAIPVLvm/+YsDf3zp16p9358WFyZ075n3O+/5nflHPmTAxZ/K9velZu38ysV/pmZC/uk5F9QPj1Y8kGgwx3MqjdhxeL+7Swb1t8OBkuzlIBSM3IuZ98vuXk900Qap7nI2ot/OI/CLiWQO0+nCfu08K+Le7jLmqNZQLAZ3k/+f/mIjaoKghoJsD7OO/rmjPalMESAUhNz/mnTe1DsSBgCwE37PMMxnQB6JORNdbv84/nwrCAgFcI8D7P+77T22u6AMRQzFinQ0D9QMAMAm7Y900XAEEJU8yAC5sg4HQCbtj3TRcA8lOa0x2F+oGAKQQcvO/Xtdd8ASBKritM6nfl9eMICxi4dR+Q2qcDwmT3/YB0tq1aIQC2NQ4FgwAIyBOAAMjzQSwIRDUBCEBUuxeNA4FQAoEhEIBAGlgHAY8RgAB4zOFoLggEEoAABNLAOgh4jAAEwGMOR3O9TSC49RCAYCLYBgEPEYAAeMjZaCoIBBOAAAQTwTYIeIgABMBDzkZTvU1AqvUQACkqCAMBjxCAAHjE0WgmCEgRgABIUUEYCHiEAATAI45GM71NIFzrIQDhyCAcBDxAAALgASejiSAQjgAEIBwZhIOABwhAADzgZDTR2wTkWg8BkKODOBCIcgIQgCh3MJoHAnIEIABydBAHAlFOAAIQ5Q5G87xNQKn1EAAlQg6LX1dVTZPXldI9y4pozJwFNOTz2VhsZKC0e/TNyPbLLX0ysg8I8Yv7Zma90jc9K1fJXqTjIQCRJmqivY937KJfLy2gGd/tpuJDVVR9+oyJpcG0FQR8RK2FcvLI75tAPt/y1Iyc+4Vty/5DACxDbawgPtO/tL7MmBHkdjwBP/n/JlwR+K2qKATAKtIGynlqzVoDuZHVjQRS03P+abTeavJDANRQsjFNYeVBmlex18YaoGg7CPh9/vF9MrLGml02BMBswgbtF1QeMGgB2d1KIIZiIABudV6k6r37+IlImYIdlxEQrgJSzK4yrgDMJmzQ/rajxw1aQHbXEvBTmt66q80HAVBLyqZ0h0+fli25tLiAsLiXgaxziZIV4g1HQwAMI4QBEHAvAQiAe32HmoOAYQIQAMMIYQAEnEVAS20gAFpoIS0IRBkBCECUORTNAQEtBCAAWmghLQhEGQEIQJQ5FM3xNgGtrYcAaCWG9CAQRQQgAFHkTDQFBLQSgABoJYb0IBBFBCAAUeRMNMXbBPS0HgKghxrygECUEIAARIkjtTZj9Zpimvb6m7qXf382k5YsXUGHD1erKtpIedPffJc++fQLWrBwMbEdVQUGJTLSVrm8QcW4bhMC4DqXRa7Ccju2UtzTf36e7nvgIRo+ahz9ZuLDxIKgVDMlm+Hip7zyOv3p2Rdo4kOP069+fR9dff3NonBt2rxFqciL8dMMiJ1c3osFuHQFAuBSxzmp2ovzlxMLwo3jb6f5CxaZXrVdu8tFAfj5rXfRiy9PpcoDmDVJL3QIgF5yyBdCYOOmzfTg75+wRAS48LPnztHb731Iv54wkXZ8t5ODsGgkAAHQCAzJlQlMf+MdOnPGum8W8ME/6eEnIALKrglJAQEIQYIAowS2bNtOH/5rhlEzmvKzCLz5jiUzaWuql9MTQwCc7iGX1u/Dj2dQVdVhS2s/66u5tLygyNIynVCYkTpAAIzQi/K8gwZkkNSSmJCg2PJ9+7+n/GUrFNMFJgguq0P7doHRqtY/n/mVqnTBiYLLVrsdbMdt2xAAt3nMwvoOGphJb//jlZBl6cLZNOn+CYo1Wbu+VDFNcILA8uZ/9ak44emrf3+RfjJ6ZHBSyW3uheDbAclIhcDAstWuK5h0fDQEwPEucmYFb7/tFsWDcp0OAZBq7bDcbHrx+T/ThLvvkIoOCWMRCAlEgCQBCIAkFgSqIXBp926yycor9sjGa41kARg+NEcxW6TLVSzQxgRGi4YAGCXo4fy7yytkW9+mdZJsvJ7IK1XcClTs0fctxV/ddS+pXfQOSdbTZjPzQADMpBvFtvkAKNu4WbaFrZMiLwDX/fQqUno4qOcKYPW3JaRlkW24iyIhAC5ylh1VlRoH/8gTT9Pd900iHpIrV6ec7MFy0brj2rdrK5u3uvoIVR85IpsGkT8SiPnxB39BIJSA1MHPYV/Nma9qpJ/aJ/ehJRsP0XsbYLxk6yxEoiQIQCQowkYIgVtvuZmUHhKGZIpgQMPYhhG0Fr2mIADR61vbWta1S2e6dfzNtpXPBScmxvMPFgUCEAAFQIjWTuCpxx+mtslttGdUkeNwdbX4sE4pqZrRiko2vBAPAfCCly1qI9/zf/DOdOIRhGYVOeOzWYqme/dKoQYNGiimC0zAQ3+1fGbdzDYG1ivceqTCIQCRIulBO/FxcdQrpQddf+3V9MarU8TRemn9U00l8c2ifEX7WYMHKKZBgh8JxPz4g78gEEqAR969PX0qBS+zPv2QCvO/puWL59KMj96lZ556jLKGDAw1EMEQHt9/7Q3jiScdUTI7ZLC5dVEq303xEAA3ecuGuvKlbvDSvVtXatGiuSm14QFGdcuiJUvp/Q8/Jh53cOsd96ia8CO1b28ampNlSt2i0SgEIBq96tI28Ug8nvSzbrl/0iP0/F//Rjzu4OjRY6paxc8hVCV0caJIVh0CEEmasGUrAX5r8Bc/v8nWOritcAiA2zyG+oYlwM8itD79D2vMIxEQAI84OpqbGRsbS++/9RolJbWK5maa0jYIgClYYdQqAiPzhtHXX31KGen9rSrS1nIiXTgEINJEYc8SAnnDc2nqy5NpykvPU2sT5h2wpBEOKAQC4AAnoArhCcTFtaTOnTpSv9Q+9F/X/ZSee+YP9OVnH4kHP4tA+JyIUUMAAqCGUhSm4b59paGvPBAoUk1XU55UfVYsnkdzZn5CH733Bv3pD4/ST8eNoW5du2iulpTtwDCeBFSz0SjIAAGIAieiCd4gYEYrIQBmUIVNEHAJAQiASxyFaoKAGQQgAGZQhU0QcAkBCIBLHIVqepuAWa2HAJhFFnZBwAUEIAAucBKqCAJmEYAAmEUWdkHABQQgAC5wEqrobQJmth4CYCZd2AYBhxOAADjcQageCJhJAAJgJl3YBgGHE4AAONxBqJ63CZjdegiA2YQN2k9s1EjWQmpmDmFxLwNZ5xJVKsQbjoYAGEZoroEecS3MLQDWnUvAR+vMrhwEwGzCBu13MWn+fYPVQnYLCPj8vi1mFwMBMJuwQfs5Jn1k02C1kN0CAhfowlyzi4EAmE3YoP3s5NY0plMHg1aQ3W0EhLP/BxtLiiAAbnOcGfV9emC6GWZh08EEStcW3GJF9XAFYAXlCJSx8vpxNKl/3whYggknE/CR77dlJYU+q+oIAbCKdATKuenSrjR9eA7d0L0LZSa1ooRGDSNgFSbsJOAnOiiUv4R8/mnk9w8tLSmYImyTVQsEwCrSESonrVUCPZSWSq8Oy6J5V40mvjLAMs42Dkpu5bO53LKxpLCNED+irLjo3rK1RSuU7EU6HgIQaaKwBwIuIgABcJGzUFUQiDQBCECkicIeCBgkYGV2CICVtFEWCDiMAATAYQ5BdUDASgIQACtpoywQcBgBCIDDHILqeJuA1a2HAFhNHOWBgIMIQAAc5AxUBQSsJgABsJo4ygMBBxGAADjIGaiKtwnY0XoIgB3UUSYIOIQABMAhjkA1QMAOAhAAO6ijTBBwCAEIgEMcgWp4m4BdrYcA2EUe5YKAAwhAABzgBFQBBOwiAAGwizzKBQEHEIAAOMAJqIK3CdjZegiAnfRRNgjYTAACYLMDUDwI2EkAAmAnfZQNAjYTgADY7AAU720CdrceAmC3B1A+CNhIAAJgI3wUDQJ2E4AA2O0BlA8CNhKAANgIH0V7m4ATWg8BsMkLb2zeRo+tKqafLVxKQz6fTTcuyKeHitbQ1NLNtOv4CZtqhWK9RgACYLHHiw9ViQf9PzZtpYV799N3x46LNdh94gQt3V9J72/bQXfmF9DbW7bTmfMXxDj8AQGzCEAAzCIrYfeBglV0z7Kiiwe9RBIx6PjZs/Taxi1059IC2nkMVwMiFPwxhQAEwBSsoUY/2bGLCisPhkbIhGw5cpQeW10MEZBh5NYop9QbAmCBJypOnKTpwiW/nqL4FgEioIcc8qghAAFQQ8lgmhk7dxNf1us1wyLw2qYterMjHwiEJQABCIsmchHFB6sMG1uy73sqPXzEsB0YAIFAAhCAQBomrPPZe+vRYxGxPK9ib0TswIi9BJxUOgTAZG+sOnhItoS7evek2WNH0Vt5ucTrcolZACprauSSIA4ENBGAAGjCpT1x/r5K2UxD27ahpMaNqG9CPN3ZqweN7dQhbHp+jrCuqjpsPCJAQCsBCIBWYhFMn5nUinrFx9WzeE3XTvW2gzfKhR6F4DBsg4BeAhAAveQikO/YmTMhVlgU2jVtEhJeF7CjduRg3TZ+3UXAabWFANjoke3CwXyg5oeQGnRv2SIkrC5g65HIPFCss4dfbxOAAJjsf7mzORe96kDoQ8I+wvMAjpNa9pw8SRf8fqkohIGAZgIQAM3ItGVIT0qUzfD1nn0h8XENY0PCAgNOnTsfuIl1ENBNAAKgG526jClxLWUTrjxwkEoOHa6XJq5hw3rbwRunzp0LDsK2Cwg4sYoQAJO9kiI85e+pIAIzd5XXq0W8ggDUQADq8cKGfgIQAP3sVOcc16WjbNq5FXvp3a07LqZpEOO7uC61cuo8bgGkuCBMOwEIgHZmmnOM69yRlB4GTivbTMv2yw8aqisYVwB1JPBrlAAEwChBFflbxMbS1V3kB/iwmZc3bFT17n+zBg04ORYXEXBqVSEAFnmGh/nyIB+54vacPCVOACKXhuOaxkIAmAMW4wQgAMYZqrZwV+8eimn57cHJ68pk0+EKQBYPIjUQgABogGU0KV8BKL3xx2WwCPBvuAUCEI4MwrUSgABoJWYwPd8KjJF540/JvE/oIGh0ySVKyRDvIAJOrgoEwAbvPD0wXXz9V0/ROPvroYY84QhAAMKRMTn89eHZ1FJhyK9UFZqiB0AKC8J0EoAA6ARnNFtsTAy9mzdUsxlcAWhGhgwyBCAAMnDMjmrfrCnxlYCWcpqhC1ALLtvTOr0CEACbPZTeKpFm/mQkqT2weWbgr3bvsbnWKD5aCEAAHODJtk2b0BeCCGQlt1ZVm2eK19EH275TlRaJQECOAARAjo6FcS1jY+ml7EGqewemlG6iaWX4WIiFLorKoiAADnLrJUInf1m1+o9/vLt1Oz1XssFBLUBVAgm4YR0C4CAvbao+qrk2X+wqp0dXFdNpvCKsmR0yEEEAHLQXFB44oKs2i/bup0mFq0lqglFdBpHJMwQgAA5ydVHlQd21WXOwih4URGBbhD5DX67mDAAADstJREFUprsiyOgqAhAAB7nL6Fd/+BuEvytaQywGDmqWJ6vilkZDABziKT545aqS3KQJ/Sa1t1wSMe77UzX0kCACfFsgBuAPCMgQgADIwLEyqlDh8j8jKZFu6dGdnhqQRgmNlGcN5geD/IDQyjagLPcRgAA4xGdK9/+ZggBwVa/q3JH+OCCd5L4exOl44S7C9wImG+UwLCAQSAACEEjDxvXiQ1WypWcktboYzyMGWQQGtv5P2MXIoJVXyjbTi+vlZxgKyoJNgwTclB0C4ABvbT4i3/+f1LgRdW7erF5NU+JbCrcD6XRlx/b1wqU2PtmxiyYWrCaec1AqHmHeJQABcIDvvxW68OSq0S8xQTK6TZPG9KTwTOCmS7tJxgcGFlQeEERgFSndagTmwXr0E4AAOMDHhQfk+/8zAy7/g6vbMCaGJvXvQ/f0SQmOCtkuP3GSJhauphnf7Q6JQ4A3CUAAHOD31RJfCA6sVkbtA8DAsOD121Iuo8cz+lPzWPkPi/KXhSevKyX+BkGwDWwbJ+A2CxAAmz2m9PJPYqNG1EPh24J1TbimayfhuUBayPOCuvjA34+276QHC9fQvlOnAoOx7jECEACbHb6hqlq2BqmJ8bLxwZHD2yXTk5lplNYqMTgqZHv595XEDwdXKVyBhGREQNQQgADY7Moihfv//mEeAMpVu3+rBHoisz+NaN9WLpkYt+v4CZpYuIo+24nnAiIQj/2BANjscOURgK101ZC7DR8Tngn8V7cuivnPXfDT82tLiScZUUyMBGEJuDECAmCj19Yflr/8j2/UkLTeAgQ2h6cd/316Kt3eq0dgcNh1nmaM3yOorKkJmwYR0UUAAmCjPxXv/xOk+/+1Vvnu3j3pwf59qbGKLwot3V9JDxSsxhuFWiG7ND0EwEbHFR86LFu6kbN/sOEbL+1KjwvPBdo1bRIcFbLN3yacWLCK8DJRCJqoC4AA2OTS834/FSnMAKTnAaBcc3jYMD8X6JMQL5dMjDtz4YI43+DU0s3iNv7IE3BrLATAJs9tEO7/+eFbuOLjGsaSmgFA4fKHCx/cJokezehHOcltwiWpF/7+th10z7IiujO/gG5dvJx+tnAp3bBgCV07fxFdNfcbGj37a8r7ch7lzpxD2V/MoRFfzqcxcxbQdUL8zd/k021CnruXFtITq0uIX0z6bGc58YPP3ULvw5nzF+qVhQ3rCUAArGculrhesf8/gWJ8PjFtpP7wAccHXtUPp2lYu2TiV4vV2OY3FVmwthw5Snx7UHHiJPHEI2zn2JmzVHPuPLGY8SjDU+fOUfXpM7T/VA3tFA7yTUKetVWHacGefcSvJj+/doPwjGEV3SiIw7BZc0VBebZkPc3aXUGHhHqpqQ/SRI4ABCByLDVZ4gNKLkOqisv0cPn5IJ1bsVcc7stnbz4bD/l8NvEBxwfeA8L9PR+Ic8rt/8IQ13XWrgp6tng9/VK4Wnhj8zYIQTjHmhAOATABqpJJvr9eqTD6LlXlACCeBHTmrnJ6QejHvyN/BQ2d+eNZ9Y9r1hIP9+WzN5+NlerkhPhDP/xA/9i0VbjdWEGzHSBOapm4OR0EwAbvcfef3Dz+LWJjKdwrwAdrfhAPjqeEA3zc3IV0y6Jl9JeSDfTpzt3E3w08Kzy8s6FJES2SBetP364jXiJqGMZCCEAAQpCYH6B4+Z8YT00aXHKxIjxcly+N/2dZIV09b6F4YMwTLvH5jHkxURSu8FUAX9lEYdMc0yQIgA2uUBoBWHf5v2x/JT2y8lu6SXhgxpfGJYfkxw3Y0BTTi+QrG57RyPSCPFoABMBix9ecP09rFQ7kKuFeeJjwhPx3RWto8b7vLa4hEU8yktykMfWKj6MGPnU9EZyK8zVr0IDiGzakpMaNiQcd8TsJl7ZsQSmCLRY27tqME+K1NOqdrduJex605LEqrdvLgQBY7EG+/z8pdJXJFct95dxlJ5dGbxwPB+bnC/ySEH9n4A8D0ujlnMH07oihNGvMSFp27VhxmTXmCjHshayBxHMSKJXnFxLwZCSvDc+m+eNG0+yxV9AXPxlJ/x6dRx9eMZzeE+y/eXkOvTYsm74W4rm8if36qHptuUroHvx4xy6hBPyPNAEIQKSJKthTuv9XyK4pum3TJmJ//+0pPei5wZk0QzgY868ZQ28IByK/JMTfGRjXuSNlJ7cmPtsnN2kinv0p4F9u2zY0OWsAdW3RPCBUevXw6dN0+5IVpOajJFzezZd1o+mCYPxFqBsp/Fuy/3tSEk4FE4iWIAABkIBiZpCZAsBzB97Vuye9OiyLvrn6SpopnIH/KpzB7+7Tk0Z2aEedgmYWVtvOVKFLcrJgh+cZUMpzVuiF4I+SaJl38AqhbrPHjpI1zb0faw4ekk2DSO0EIADamenOwbP/Kj0A1GK87oD/e+4QWiqc2fnAv7NXD+Jw7krUYkspLd/LswgMbZuslFSM53kH396yXVxX84enPn8xe5Bs0h3HTsjGWx0ZDeVBACzwIo9957H0E5YX0cmz53SX2Dchnsb36E4vCJfk868aLZ7p+YDn8f2NVLzqq7vg2oz8cI9vB/i2oTZI9ue1jVvoydUl4rBg2YS1kXxbULsq+bP1yFHJcATqJwAB0M9OMWe+0I3Hffc89FbvpT+feccLBz0/PHsrL5fuT+1Nl7drSzxZiGIFTEjA7yfwg8OfCffvasx/vWcf/WbFSlqkojej/IT8GV5pAlU19UGa+gQgAPV5RGSLH4Ldt3wlPSx04+npu+eD+5ouncQHd+8IT8/5oM9ISoxI3SJl5AHhCT4/W1Bjj7vwHl35rfg2oFz6L3fLv5vQsVn9ryPJ2UKcOgIQAHWcVKX6cTadVcQPwVZrfGB1idDfPlR44s4z90wfnkM8eQc/uON+dVWF25CIexceSktVXTK/DcivEvO3CvllJX6PgTPz0F8e2qz0clJPldOjs02zl2ixDwGIgCf5VdjJ68qI59Pj+309JqcOHUL8EIxn7umi82m9nnKN5rmhexf686AM4s+UqbHFVwM8so9fVuL3GPgtRX5bkYc2K+XvlRCnlATxGglAADQCC06+/ehxuiN/Bc34Tv9AlX5CNxs/uQ+27Zbt0R3bEwuYmmnI9bapZcNYoXfDWbdBetvipHwQAAPe4Dnzxi9aSkpf91UqIl3FRzyUbNgd36V5c/rfIQPovtRexLczka7P2E4diAcqRdqu1+1BAHTuAfcKXXrPlWxQnVvuEnlA61aq7Tg94S96XEqvDM0iNYOG1LaF3zFQ2/Wo1qaRdNGUFwKgw5v8kG/NwSpVOXkUHU/LfaDmB8n03Vu2EIfiSka6NJB7LFgEfq6yq1Cpmff36y2+TKSUDvHaCUAANDKbWrZZ1Vh3NvtkZpo4jn6+0BfO21LLwCg6+we2j8/avxW6CrlHY1SHdoFRqtebNLiEpuQOpv/u3lV1HiTURgACoIHXzF0V9P7WHYo5+KHY51eOoKu7dKT5FfuIJ/QIl0nt7Lzh8js9PK1VAj07OJP+L2cQXd+tM7Vq3EixyvwaMb+o9ObluTSkTWvF9EignwAEQCW78hMnaZpw9ldKflvKZWK3WPtmTemC30/z9+wNm6Vbi+ZRd/kfrrEsdI+k96NPRuWJDwuZE79pyL0fvPA6h/GDxH+Nupz4VWWeRyCcPbvCo61cCIBKj/J3846cOSOb+rqunemePikX08wp30ubqsOPXx+h89L4YgEuXGke24C4u5A5vZQ9SHyfgV9i4nUO4zies8CFTXNllSEAKtzGg3u4y08u6S97XiZ+cCMwzZwK+aGtI9u3DUyOdRCwnAAEQAVyPvvLJeMPbEzo+58zP6flF4H49V9el1qGtU2mHhjaKoUGYRYSgAAowOY5+eTG9fNB/IDQTRVo5vjZs8SvwgaGBa+P6ICzfzATp29HY/0gAApeVXoFlR9exQVNcjmldJP4Ca1wpge1TiIMbAlHB+FWEoAAKNAuVhjww9NZBZrgb9zxp64Cw4LX+f3+4DBsg4AdBCAACtQrTp6UTRH4iiqPEXi2eL1seu4p4Ek4ZRMhEgQsIgABUAAdGyOPqObceeJ5/u5dvpJ4lKCcOZ5SC2d/OULOjYvWmsnv3dHaag3tCjzDS2XL+3Ie3ZVfQGtUTADCM+jwFF9SdhAGAnYQgAAoUL+sZUuFFOqi+UMcvKhLjVQgYA0BCIAC5y4tjM9Dx/f8/CEOhaIQDQKWE4AAKCDnWwC138eTMsVTfPGnt6TiEOYOAtFcSwiAgndT4uOID2KFZJLRj2b0I57kUzISgSDgAAIQABVO4Pfa1Xwgs84Ujw7kiTK5y68uDL8g4EQCEACVXpl71Sji7+7JJW/btIn44Y638nKJ5wSQS4s4EHACAQiABi/wZ7heH5Ytfp5rTKcOxJ/k4l8WhmcGZdDbwoHP/fw8Gw7hX1QQiPZGQAA0ejg9KVE8yz89MJ3+njuE+JeF4cqO7UnLbYLGYpEcBEwhAAEwBSuMgoA7CEAA3OEn1BIETCEAATAFK4xGAwEvtAEC4AUvo40gEIYABCAMGASDgBcIQAC84GW0EQTCEIAAhAGDYG8T8ErrIQBe8TTaCQISBCAAElAQBAJeIQAB8Iqn0U4QkCAAAZCAgiBvE/BS6yEAXvI22goCQQQgAEFAsAkCXiIAAfCSt9FWEAgiAAEIAoJNbxPwWushAF7zONoLAgEEIAABMLAKAl4jAAHwmsfRXhAIIAABCICBVW8T8GLrIQBe9DraDAK1BCAAtSDwAwJeJAAB8KLX0WYQqCUAAagFgR9vE/Bq660QgEo5uEM+n01YwMCt+4Dcvi3Eye77Qrzt/80XAB+ts72VqAAI2EHABfu+6QLg8/u22MEeZYKA3QTcsO+bLgAX6MJcux2B8kFAjoBZcW7Y900XgI0lRXMFJfzALMiwCwJOJMD7PO/7TqxbYJ1MFwAurHRtwS38iwUEvELALfu8JQLATi8rKfT5yPdbXscCAtFKgPdx3tfd0j7LBICBlJYUTCG/fyj5/NOE7SV+ooPCL/6DgG0EjBZcuw8vEfdpYd8W93GjRi3M//8AAAD//65CnYIAAAAGSURBVAMAXOQ3J6xftlcAAAAASUVORK5CYII=
// @grant        none
// @noframes
// ==/UserScript==

(function () {

    'use strict';
    console.log("%c[PDF扩展] 载入成功", "color: #4caf50; font-weight: bold;");

    /*** ① 自动查找 PDF.js 上下文 ***/
    (function findPDFViewerContext(attempt = 1) {
        const MAX_ATTEMPTS = 5; // 最大尝试次数
        const ctxList = [];

        function scanWindow(win) {
            try {
                if (win.PDFViewerApplication && win.PDFViewerApplication.download) {
                    console.log("%c找到 PDF.js 上下文：", "color: green; font-weight: bold;");
                    console.log(win);
                    ctxList.push(win);
                }
            } catch (e) { }
            try {
                const frames = win.document.querySelectorAll("iframe");
                for (const f of frames) scanWindow(f.contentWindow);
            } catch (e) { }
        }

        scanWindow(window);

        if (ctxList.length > 0) {
            console.log("%c成功！请使用 window.__PDFCTX 来访问 PDF.js。", "color: blue");
            window.__PDFCTX = ctxList[0];
        } else if (attempt < MAX_ATTEMPTS) {
            console.log(`%c未找到 PDF.js，上下文尚未加载，正在重试…（第 ${attempt} 次）`, "color: orange");
            setTimeout(() => findPDFViewerContext(attempt + 1), 500);
        } else {
            console.log("%c❌ PDF.js 上下文查找失败，已达到最大尝试次数。", "color: red; font-weight: bold;");
        }
    })();

    /*** ② UI 元素（按钮 + 进度条 + 浮动链接框） ***/
    const OFFSET = 300;   // 上移距离
    const OFFSET_X = 595; // 左移距离


    // ①：把你的 CSS 写入页面
    const style = document.createElement("style");
    style.innerHTML = `
                    .download-button {
                      position: fixed;
                      bottom: 300px;
                      left: 50%;
                      transform: translateX(-50%);
                      width: 200px;
                      height: 60px;
                      border: 2px solid #282828;
                      border-radius: 5px;
                      background-color: #212121;
                      color: #FFD700;     /* 改成你要的黄色字体 */
                      display: flex;
                      align-items: center;
                      justify-content: center;
                      overflow: hidden;
                      box-shadow:
                        0 4px 8px rgba(0, 0, 0, 0.5),
                        inset 0 1px 3px rgba(255, 255, 255, 0.3);
                      cursor: pointer;
                      font-size: 20px;
                      font-weight: bold;
                      text-align: center;
                      font-family: Arial, sans-serif;
                      transition:
                        background-color 0.3s,
                        color 0.3s,
                        transform 0.2s;
                    }

                    .download-button::before {
                      content: "";
                      position: absolute;
                      top: -100%;
                      left: 0;
                      right: 0;
                      bottom: 100%;
                      border-radius: 5px;
                      background: linear-gradient(
                        180deg,
                        rgba(255, 255, 255, 0.2) 0%,
                        rgba(255, 255, 255, 0.1) 100%
                      );
                      z-index: 1;
                      transition: top 0.5s ease-in-out, bottom 0.5s ease-in-out;
                    }

                    .download-button:hover::before {
                      top: 0;
                      bottom: 0;
                    }

                    .download-button:hover {
                      background-color: #465243;
                      color: #fff;
                      transform: translateY(-5px);
                    }
                `;
    document.head.appendChild(style);

    // ②：创建按钮
    const btn = document.createElement("button");
    btn.className = "download-button";
    btn.innerText = "✔ 下载 PDF";

    document.body.appendChild(btn);

    console.log('给我扫个五元 ！✅ ！谢谢')

    style.innerHTML += `
.preview-button {
  position: fixed;
  bottom: 230px;  /* 比下载按钮低一点 */
  left: 50%;
  transform: translateX(-50%);
  width: 200px;
  height: 50px;
  border: 2px solid #404040;
  border-radius: 5px;
  background-color: #2a2a2a;
  color: #FFD700;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow:
    0 4px 8px rgba(0, 0, 0, 0.5),
    inset 0 1px 3px rgba(255, 255, 255, 0.3);
  cursor: pointer;
  font-size: 18px;
  font-weight: bold;
  text-align: center;
  font-family: Arial, sans-serif;
  transition:
    background-color 0.3s,
    color 0.3s,
    transform 0.2s;
}

.preview-button:hover {
  background-color: #505a50;
  color: #fff;
  transform: translateY(-4px);
}
`;
    // 创建预览按钮
    const previewBtn = document.createElement("button");
    previewBtn.className = "preview-button";
    previewBtn.innerText = "👁 预览 PDF";
    document.body.appendChild(previewBtn);

// 预览功能
    previewBtn.onclick = () => {
        if (!window.__PDFCTX) {
            alert("❌ PDF.js 上下文未找到，请等待加载完成后再试。");
            return;
        }

        const url = window.__PDFCTX.PDFViewerApplication.baseUrl;
        const fullUrl = new URL(url, window.location.href).href;

        // 新标签页打开 PDF
        window.open(fullUrl, "_blank");
    };

    // 进度条容器
    const progWrap = document.createElement("div");
    Object.assign(progWrap.style,{
        position:"fixed", bottom:(80+OFFSET)+"px", right:(15+OFFSET_X)+"px",
        width:"260px", height:"32px", background:"rgba(0,0,0,0.3)",
        borderRadius:"12px", padding:"4px", display:"none", zIndex:999999
    });

    const progBar = document.createElement("div");
    Object.assign(progBar.style,{
        height:"100%", width:"0%", background:"#4caf50",
        borderRadius:"10px", transition:"width 0.15s"
    });
    progWrap.appendChild(progBar);
    document.body.appendChild(progWrap);

    // 百分比文字
    const progText = document.createElement("span");
    Object.assign(progText.style,{
        position:"fixed", bottom:(88+OFFSET)+"px", right:(23+OFFSET_X)+"px",
        fontSize:"16px", color:"#fff", zIndex:1000000, display:"none"
    });
    progText.innerText = "0%";
    document.body.appendChild(progText);

    // 浮动下载链接框
    const linkBox = document.createElement("div");
    Object.assign(linkBox.style,{
        position:"fixed", bottom:(130+OFFSET)+"px", right:(20+OFFSET_X)+"px",
        padding:"10px 14px", background:"rgba(0,0,0,0.6)", color:"#fff",
        borderRadius:"8px", fontSize:"14px", zIndex:999999,
        maxWidth:"300px", overflow:"hidden", textOverflow:"ellipsis",
        whiteSpace:"nowrap", cursor:"pointer", boxShadow:"0 0 10px rgba(0,0,0,.4)",
        display:"none"
    });
    linkBox.title="点击复制下载链接";
    document.body.appendChild(linkBox);

    linkBox.addEventListener("click", ()=>{
        navigator.clipboard.writeText(linkBox.dataset.url).then(()=>{
            linkBox.innerText = "✅ 链接已复制!";
            setTimeout(()=>{ linkBox.style.display="none"; },5000);
        });
    });

    /*** ③ 下载逻辑（单线程） ***/
    btn.onclick = async () => {
        if(!window.__PDFCTX){
            alert("❌ PDF.js 上下文未找到，请等待加载完成后再试。");
            return;
        }

        const url = window.__PDFCTX.PDFViewerApplication.baseUrl;
        const fullUrl = new URL(url, window.location.href).href;

        // 显示链接框
        linkBox.dataset.url = fullUrl;
        linkBox.innerText = fullUrl;
        linkBox.style.display = "block";

        // 显示进度条
        progWrap.style.display = "block";
        progText.style.display = "block";
        progBar.style.width = "0%";
        progText.innerText = "0%";

        try {
            const response = await fetch(url);
            const reader = response.body.getReader();
            const contentLength = +response.headers.get("Content-Length");
            let received = 0;
            const chunks = [];

            while(true){
                const {done,value} = await reader.read();
                if(done) break;
                chunks.push(value);
                received += value.length;
                const pct = ((received/contentLength)*100).toFixed(1);
                progBar.style.width = pct+"%";
                progText.innerText = pct+"%";
            }

            const blob = new Blob(chunks, {type:"application/pdf"});
            const a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = "成功下载.pdf";
            a.click();
            URL.revokeObjectURL(a.href);

            progBar.style.width = "100%";
            progText.innerText = "100%";

            setTimeout(()=>{
                progWrap.style.display = "none";
                progText.style.display = "none";
            },5000);

        } catch(e){
            console.error("下载失败:", e);
            alert("❌ PDF 下载失败！请确认 window.__PDFCTX 已找到");
        }
    };
})();
